"use client";

import { useEffect } from "react";
import OneSDKHandler from "./OneSDKHandler";

/**
 * OneSDKFlow component handles the initialization and flow of OneSDK.
 * It configures OCR, biometrics, and form components with Incode provider and Google Places API.
 */
const OneSDKFlow = () => {
    // Configuration object for OneSDK setup with OCR, biometrics, and form components
    const config = {
        mode: "development", // Development mode
        recipe: {
            ocr: {
                provideReviewScreen: false, // OCR review screen disabled
                provider: {
                    name: "incode", // OCR provider set to "incode"
                },
            },
            biometrics: {
                provider: {
                    name: "incode", // Biometrics provider set to "incode"
                },
            },
            form: {
                provider: {
                    name: 'react', // Form provider set to React-based forms
                    googleApiKey: import.meta.env.VITE_GOOGLE_PLACES_API_KEY, // Google Places API key from environment variables
                },
            },
        },
    };

    // Destructure OneSDKHandler response, which includes SDK instance, error, and loading state
    const { oneSDKInstance, error: errorOneSDK, loading } = OneSDKHandler({ config });

    /**
     * Initializes the OneSDK flow and mounts components.
     * The flow includes WELCOME, CONSENT, IDV, REVIEW, and RESULT screens.
     */
    const initOneSDK = () => {
        // Listen to all events emitted by the SDK
        oneSDKInstance.on('*', console.log);

        // Initialize IDV (Identity Verification) flow
        const idv = oneSDKInstance.flow('idv');

        // Define components for the flow
        const welcome = oneSDKInstance.component("form", {
            name: "WELCOME",
            type: "ocr",
        });
        const consent = oneSDKInstance.component("form", { 
            name: "CONSENT", 
            type: "ocr", 
        });
        const review = oneSDKInstance.component("form", {
            name: "REVIEW",
            type: "ocr",
            verify: true,
        });
        const form_result = oneSDKInstance.component("form", {
            name: "RESULT",
            type: "manual",
            state: 'SUCCESS',
            title: { label: 'Complete' },
            descriptions: [{ label: 'Process is now complete. You can close the page' }],
            cta: { label: 'Done' },
        });

        // Mount the first component (WELCOME) to the DOM
        welcome.mount('#onesdk-container');

        // Event handler when WELCOME form is ready
        welcome.on("form:welcome:ready", () => {
            // Mount CONSENT component when WELCOME form is ready
            consent.mount("#onesdk-container");
        });

        // Event handler when CONSENT form is ready
        consent.on("form:consent:ready", async () => {
            // Mount IDV (Identity Verification) component when CONSENT form is ready
            idv.mount("#onesdk-container");
        });

        // Event handler for IDV result status
        idv.on('results', ({ checkStatus }) => {
            // If the check status is successful, mount the REVIEW component
            if (checkStatus) {
                review.mount("#onesdk-container");
            }
        });

        // Event handler when REVIEW form is ready
        review.on('form:review:ready', async () => {
            // Mount the final RESULT component when REVIEW form is ready
            form_result.mount("#onesdk-container");
        });
    };

    // useEffect hook to initialize OneSDK when the SDK instance is available
    useEffect(() => {
        if (oneSDKInstance) {
            initOneSDK();
        }
    }, [oneSDKInstance]);

    // Render the loading state or the container for mounting OneSDK components
    return loading ? (
        <div>Loading...</div>
    ) : (
        <div id="onesdk-container" className="onesdk-container"></div>
    );
};

export default OneSDKFlow;
