import './App.css'
import OneSDKFlow from './OneSDKFlow'

function App() {
  return (
    <>
      <div>
        <OneSDKFlow />
      </div>
    </>
  )
}

export default App
